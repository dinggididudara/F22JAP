/**
 * File Name : Main.java
 * Identification : Soomin113
 * Course : CST8221 - JAP, Lab Section : 302
 * Assignment : A11
 * Professor : Paulo Sousa
 * Date : Sep-30
 * Compiler : Eclipse IDE
 * Purpose : Number Puzzle - main class
 */
package Main;


public class Main {

	public static void main(String[] args) {
		new design();
	} //main end
} //Main class end
